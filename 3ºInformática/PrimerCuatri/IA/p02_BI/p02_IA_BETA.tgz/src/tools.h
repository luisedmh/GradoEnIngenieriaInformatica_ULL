struct Args {
	std::string input_file;
	std::string output_file;
};
