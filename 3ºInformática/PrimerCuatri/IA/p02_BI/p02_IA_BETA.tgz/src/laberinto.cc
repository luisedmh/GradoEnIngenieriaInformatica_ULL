/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Inteligencia Artificial
* Curso: 3º Práctica 02: Búsquedas informadas
* Autor: Luis Eduardo Martín Hernández
* Correo: alu0101631134@ull.edu.es
* Fecha: 14/10/2025
* Archivo laberinto.cc:                                                                                               
* Implementación de la clase Laberinto
* Referencias:
* Historial de Revisiones:
*/

#include "laberinto.h"

Laberinto::Laberinto(const std::string& input_file) : filas_(0), columnas_(0), inicio_({-1, -1}), fin_({-1, -1}), num_paredes_(0) {
	
	std::ifstream archivo(input_file);
	if (!archivo.is_open()) {
		throw std::runtime_error("No se pudo abrir el archivo: " + input_file);
	}

	archivo >> filas_ >> columnas_;

	laberinto_.resize(filas_, std::vector<char>(columnas_));

	for (int i = 0; i < filas_; i++) {
		for (int j = 0; j < columnas_; j++) {
			char c;
			archivo >> c;
			if (c == '1') {
				num_paredes_++;
			}
			if (c == '3') {
				inicio_ = {i, j};
			} else
			if (c == '4') {
				fin_ = {i, j};
			}
			laberinto_[i][j] = c;
		}
	}

	std::cout << "Laberinto inicial cargado. ¿Desea cambiar el inicio y final?" << std::endl;
	std::string respuesta;
	std::cin >>	respuesta;
	if (respuesta == "sí" || respuesta == "Sí" || respuesta == "Si" || respuesta == "si" || respuesta == "Yes" || respuesta == "yes" || respuesta == "y" || respuesta == "Y" || respuesta == "S" || respuesta == "s") {
		std::cout << "Introduzca la nueva dirección de inicio del laberinto con el siguiente formato 'i j': ";
		int i;
		int j;
		std::cin >> i >> j;
		std::cout << std::endl;

		if ((i - 1) >= 0 && (j - 1) >= 0) {
			laberinto_[i - 1][j - 1] == '3';
			laberinto_[inicio_.first][inicio_.second] = '1';
			inicio_.first = i - 1;
			inicio_.second = j - 1;
		} else {
			laberinto_[i][j] == '3';
			laberinto_[inicio_.first][inicio_.second] = '1';
			inicio_.first = i;
			inicio_.second = j;
		}
		
		std::cout << "Introduzca la nueva dirección de fin del laberinto con el siguiente formato 'i j': ";
		std::cin >> i >> j;
		std::cout << std::endl;

		if ((i - 1) >= 0 && (j - 1) >= 0) {
			laberinto_[i - 1][j - 1] == '4';
			laberinto_[fin_.first][fin_.second] = '1';
			fin_.first = i - 1;
			fin_.second = j - 1;
		} else {
			laberinto_[i][j] == '4';
			laberinto_[fin_.first][fin_.second] = '1';
			fin_.first = i;
			fin_.second = j;
		}
	}
}

void Laberinto::ImprimirLaberinto() {
	for (int i = 0; i < filas_; i++) {
		std::cout << "|";
		for (int j = 0; j < columnas_; j++) {
			std::cout << " " << laberinto_[i][j] << " ";
		}
		std::cout << "|" << std::endl; 
	}
}

Nodo Laberinto::ImprimirCamino(const std::vector<Nodo>& inspeccionados, int aux) {
    Laberinto laberinto_aux = *this;
    
    // Reconstruir camino
    std::vector<std::pair<int, int>> camino;
    int actual = aux;
    
    while (actual != -1) {
        camino.insert(camino.begin(), inspeccionados[actual].getPos());  // Insertar al principio
        actual = inspeccionados[actual].getIPadre();
    }
    
    for (size_t i = 1; i < camino.size(); i++) {
        laberinto_aux.laberinto_[camino[i].first][camino[i].second] = '*';
    }
    
    std::cout << "Camino encontrado (" << camino.size() << " pasos): ";
    for (size_t i = 0; i < camino.size(); i++) {
        std::cout << "(" << camino[i].first << "," << camino[i].second << ")";
        if (i < camino.size() - 1) std::cout << " -> ";
    }
    std::cout << std::endl;
    
    laberinto_aux.ImprimirLaberinto();
    
    // Devolver el primer movimiento (camino[1])
    if (camino.size() > 1) {
        return Nodo(camino[1].first, camino[1].second);
    } else {
        return Nodo(camino[0].first, camino[0].second);
    }
}

int Laberinto::CalcularCosteEstimado(const Nodo& nodo) {
	const int W = 3;
	int coste_estimado = ((std::abs(fin_.first - nodo.getPos().first) + std::abs(fin_.second - nodo.getPos().second)) * W) + nodo.getCosteAcumulado();
	return coste_estimado;
}


Nodo Laberinto::ResolverEstatico() {
	std::vector<Nodo> inspeccionados;
	int aux = 0;	// Iterador del vector de inspeccionados
	
	std::vector<Nodo> frontera;

	Nodo nodo_inicial(inicio_.first, inicio_.second, -1, 0);
	int estimado_nodo_inicial = CalcularCosteEstimado(nodo_inicial);
	nodo_inicial.setCosteEstimado(estimado_nodo_inicial);
	
	inspeccionados.push_back(nodo_inicial);		// El nodo inicial va a ser el primero en inspeccionarse
	
	const std::vector<std::pair<int, int>> Direcciones = {
		{-1, 0},	// Arriba
		{1, 0},		// Abajo  
		{0, -1},	// Izquierda
		{0, 1},		// Derecha
		{-1, -1},	// Diagonal superior izquierda
		{-1, 1},	// Diagonal superior derecha
		{1, -1},	// Diagonal inferior izquierda
		{1, 1}		// Diagonal inferior derecha
	};
	const std::vector<int> Costes = {5, 5, 5, 5, 7, 7, 7, 7};

	bool final_encontrado = false;

	while (aux < inspeccionados.size() && !final_encontrado) {
		Nodo actual = inspeccionados[aux];
		
		if (actual.getPos().first == fin_.first && actual.getPos().second == fin_.second) {
			final_encontrado = true;
			std::cout << "Final encontrado" << std::endl;
			Nodo nodo_siguiente = ImprimirCamino(inspeccionados, aux);
			return nodo_siguiente;
			break;
		}

		// Generar los nodos vecinos
		for (int i = 0; i < Direcciones.size(); i++) {
			int nueva_fila = actual.getPos().first + Direcciones[i].first;
			int nueva_columna = actual.getPos().second + Direcciones[i].second;
			// Verificar límites del laberinto
			if (nueva_fila >= 0 && nueva_fila < filas_ && nueva_columna >= 0 && nueva_columna < columnas_) {
				if (laberinto_[nueva_fila][nueva_columna] != '1') {
					
					int coste_acumulado = actual.getCosteAcumulado() + Costes[i];
					Nodo vecino(nueva_fila, nueva_columna, aux, coste_acumulado);
					int coste_estimado = CalcularCosteEstimado(vecino);
					vecino.setCosteEstimado(coste_estimado);
					
					// VERIFICAR SI DEBEMOS AÑADIR EL VECINO A FRONTERA
					bool en_inspeccionados = false;
					bool en_frontera = false;
					int indice_en_frontera = -1;
					
					// Comprobar si está en inspeccionados
					for (const auto& nodo : inspeccionados) {
						if (nodo.getPos() == vecino.getPos()) {
							en_inspeccionados = true;
							break;
						}
					}
					if (!en_inspeccionados) {
						// Comprobar si está en frontera y obtener su índice
						for (int j = 0; j < frontera.size(); j++) {
							if (frontera[j].getPos() == vecino.getPos()) {
								en_frontera = true;
								indice_en_frontera = j;
								break;
							}
						}
						
						// Lógica de añadido según las reglas
						if (!en_frontera) {
							// No está ni en inspeccionados ni en frontera -> Añadir a frontera
							frontera.push_back(vecino);
						}
						else if (en_frontera) {
							// Está en frontera -> Comparar costes y actualizar si es mejor
							if (vecino.getCosteEstimado() < frontera[indice_en_frontera].getCosteEstimado()) {
								frontera[indice_en_frontera] = vecino;  // Reemplazar con mejor camino
							}
						}
					}
				}
			}
		}
		// Seleccionar el mejor nodo de la frontera para la siguiente iteración
			if (!frontera.empty()) {
				int mejor_indice = 0;
				for (int i = 1; i < frontera.size(); i++) {
						if (frontera[i].getCosteEstimado() < frontera[mejor_indice].getCosteEstimado()) {
								mejor_indice = i;
						}
				}
				inspeccionados.push_back(frontera[mejor_indice]);
				frontera.erase(frontera.begin() + mejor_indice);
			}
			aux++;
	}
	if (!final_encontrado) {
		std::cout << "No se ha encontrado un final" << std::endl;
		throw std::runtime_error("No se encontró camino al final");
	}
}


void Laberinto::MezclarLaberinto() {
	float P_in = 0.5;
	float P_out = 0.5;
	const float Porcentaje_max = 0.25;
	
	int size = filas_ * columnas_;
	int num_paredes_max = static_cast<int>(size * Porcentaje_max);

	bool exceso_paredes = num_paredes_max <= num_paredes_ ? true : false;

	//float num = (float)rand() / RAND_MAX;
	for (int i = 0; i < filas_; i++) {
		for (int j = 0; j < columnas_; j++) {
			float num = (float)rand() / RAND_MAX;
			if (laberinto_[i][j] == '1' && num <= P_out) {
				laberinto_[i][j] = '0';
				num_paredes_--;
				if (exceso_paredes) {
					exceso_paredes = num_paredes_max <= num_paredes_ ? true : false;
				}
			} else
			if (laberinto_[i][j] == '0' && !exceso_paredes && num <= P_in) {
				laberinto_[i][j] = '1';
				num_paredes_++;
			}
		}
	}
	if (exceso_paredes) {
		MezclarLaberinto();
	}
}

void Laberinto::ResolverDinamico() {
	std::vector<Nodo> camino;
	int aux = 0;
	
	const int Num_iter_max = 5;

	Nodo nodo_inicial(inicio_.first, inicio_.second, -1, 0);
	int estimado_nodo_inicial = CalcularCosteEstimado(nodo_inicial);
	nodo_inicial.setCosteEstimado(estimado_nodo_inicial);
	camino.push_back(nodo_inicial);

	bool final_encontrado = false;
	int i = 0;
	while(!final_encontrado && i < Num_iter_max) {
		try {
			Nodo nodo_actual = ResolverEstatico();
			nodo_actual.setIPadre(aux);
			if (nodo_actual.getPos().first == fin_.first && nodo_actual.getPos().second == fin_.second) {
				final_encontrado = true;
				std::cout << "Camino dinámico encontrado" << std::endl;
				camino.push_back(nodo_actual);
				aux++;
				Nodo nodo_inutil = ImprimirCamino(camino, aux);
				return;
			}
			camino.push_back(nodo_actual);
			aux++;
			setInicio(nodo_actual.getPos().first, nodo_actual.getPos().second);
			MezclarLaberinto();
			i = 0;
		} catch (const std::runtime_error& e) {
			i++;			
			if (i < Num_iter_max) {
				std::cout << "Reorganizando laberinto..." << std::endl;
				MezclarLaberinto();
			} else {
				std::cout << "Destino inalcanzable después de " << Num_iter_max << " reintentos" << std::endl;
				return;
			}
		}
		
		
	}
}
