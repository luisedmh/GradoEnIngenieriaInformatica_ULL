/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Inteligencia Artificial
* Curso: 3º Práctica 02: Búsquedas informadas
* Autor: Luis Eduardo Martín Hernández
* Correo: alu0101631134@ull.edu.es
* Fecha: 14/10/2025
* Archivo BI.cc:                                                                                               
* Implementación de la fución main del programa
* Referencias:
* Historial de Revisiones:
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <utility>

#include "tools.h"
#include "laberinto.h"
#include "nodo.h"

int main(int argc, char* argv[]) {
    srand(time(0));
    // Verificar número de argumentos
    if (argc != 2) {
        std::cerr << "Error: Número incorrecto de argumentos." << std::endl;
        return 1;
    }

    std::string archivo_laberinto = argv[1];

    try {
        // Crear el laberinto
        std::cout << "=== CARGANDO LABERINTO ===" << std::endl;
        Laberinto laberinto(archivo_laberinto);
        
        // Mostrar el laberinto
        std::cout << "\n=== LABERINTO ===" << std::endl;
        laberinto.ImprimirLaberinto();

        std::cout << "\n=== INTENTO DE EJECUCIÓN ESTÁTICA ===" << std::endl;
        laberinto.ResolverEstatico();
        
        std::cout << "\n=== PRUEBA COMPLETADA ===" << std::endl;

        std::cout << "\n\n=== INTENTO DE EJECUCIÓN DINÁMICO ===" << std::endl;
        laberinto.ResolverDinamico();
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}