#ifndef TOOLS_H
#define TOOLS_H

#include <string>
#include <vector>
#include <utility>
#include <cmath>

struct Args {
    std::string input_file;
    std::string output_file;
};

struct Datos {
    int iteracion;
    int reintentos;
    int coste;
    int coste_total = 0;
    int num_generados_iter;
    std::vector<std::pair<int, int>> generados;
    int num_inspeccionados_iter;
    std::vector<std::pair<int, int>> inspeccionados;
    int num_pasos;
    float proporcion_media;
    int num_generados_total = 0;;
    int num_inspeccionados_total = 0;
};

void MostrarAyuda(const std::string& program_name);
Args ObtenerArgs(int argc, char* argv[]);

#endif